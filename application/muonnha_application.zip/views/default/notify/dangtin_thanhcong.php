<section class="home_content">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-lg-offset-2 col-sm-offset-2">
                        <div class="main_title2" style="text-align: center;"><h2 style="color: #38a345;font-weight:bold;">Thông báo</h2></div>
                        <div style="font-size:14px;text-align: justify;">
                        <p>Bạn đã đăng thành công tin rao có  tiêu đề: <strong>"<?=$this->session->flashdata('post_title')?>"</strong></p>
                        <p>Mã tin của bạn: <strong><?=$this->session->flashdata('post_id')?></strong></p>
                        <p>Chúng tôi sẽ tiến hành kiểm duyệt tin rao của bạn trong vòng 8 tiếng trở lại. Tin rao của bạn sẽ được hiển thị trên website muonnha.com.vn ngay sau khi chúng tôi kiểm duyệt xong.
Cảm ơn bạn đã tin tưởng và sử dụng dịch vụ đăng tin hiệu quả của muonnha.com.vn</p>
                        <p>Chúc bạn một ngày làm việc vui vẻ, may mắn và thành công.<br /></p>
                        <p style="text-align: center;">***</p>
                        <p>Nếu gặp bất kỳ khó khăn gì trong việc đăng ký, đăng nhập, đăng tin hay trong việc sử dụng website nói chung, Bạn hãy liên hệ ngay với chúng tôi theo số đt: <strong>0908 14 94 88</strong> hoặc email: <strong><a href="mailto:muonnha.com.vn@gmail.com" rel="nofollow">muonnha.com.vn@gmail.com</a></strong> để được trợ giúp.</p>
                        
                        </div>
                        <center><strong><a href="<?=site_url()?>" rel="nofollow">Quay lại trang chủ</a></strong></center>
                    </div>
                    
                    
                </div>
            </div>
        </section>
