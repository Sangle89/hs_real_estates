<section class="home_content">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-lg-offset-2 col-sm-offset-2">
                        <div class="main_title2" style="text-align: center;"><h2 style="color: #38a345;font-weight:bold;">Thông báo</h2></div>
                        <div style="font-size:14px;text-align: justify;">
                        <p>Quý khách đã kích hoạt tài khoản có email <?=$this->session->flashdata('email')?> tại website muonnha.com.vn thành công.</p>
                        <p>Mời Quý khách tiến hành <a href="/dang-nhap">Đăng nhập</a> để sử dụng dịch vụ đăng tin hiệu quả của website muonnha.com.vn</p>
                        <p>Chúc Quý khách một ngày làm việc vui vẻ, may mắn và thành công.</p>
                        <p class="text-center">***</p>
                        <p>Nếu gặp bất kỳ khó khăn gì trong việc đăng ký, đăng nhập, đăng tin hay trong việc sử dụng website nói chung, Bạn hãy liên hệ ngay với chúng tôi theo số đt: <strong>0908 14 94 88</strong> hoặc email: <strong>muonnha.com.vn@gmail.com</strong> để được trợ giúp.</p>
                        </div>
                        <center><strong><a href="<?=site_url()?>" rel="nofollow">Quay lại trang chủ</a></strong></center>
                    </div>
                </div>
            </div>
        </section>