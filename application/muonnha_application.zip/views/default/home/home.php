<?php
$this->load->view('default/home/search_top');
$this->load->view('default/home/list_real');
$this->load->view('default/home/list_content');
$this->load->view('default/home/newsletter');
?>