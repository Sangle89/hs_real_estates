<div class="main-wrap-content">
                <div class="row">
                    <div class="col-md-9 col-sm-9 col-xs-12">
                        <h3 style="margin: 0 0 10px 0;font-size: 16px;font-weight: 600;">Cho thuê bất động sản trên Muonnha.com.vn</h3>
                        <p>Muonnha.com.vn có hơn 100.000+ tin <a href="<?=base_url()?>" style="font-weight: bold;">cho thuê bất động sản</a> tại Tp Hồ Chí Minh. Chúng tôi liệt kê danh sách nhiều thông tin nhà đất nhất phục vụ mọi nhu cầu, từ cho thuê phòng trọ, cho thuê nhà, cho thuê căn hộ, cho thuê mặt bằng, cho thuê văn phòng cho tới tìm người ở ghép. Bạn là Chủ nhà cho thuê hay gia đình cần nhà để ở? Muonnha.com.vn đều có thể giúp bạn. Tìm tin cho thuê nhà mới nhất bằng cách sử dụng công cụ tìm kiếm hoặc các đường link ngay trên trang chủ.</p>
                    </div>
                    <div class="col-md-3 col-sm-3 col-xs-12">
                        <form class="form-newsletter">
                            <p style="margin: 0 0 10px 0;font-size: 16px;font-weight: 600;">Đăng ký nhận bản tin</p>
                            <div class="input-group">
                              <input type="text" class="form-control" placeholder="Email" aria-label="Email" aria-describedby="input-newsletter-email">
                              <span class="input-group-addon" id="input-newsletter-email">Đăng ký</span>
                            </div>
                        </form>
                    </div>
                </div>
            </div>