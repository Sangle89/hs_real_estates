<!-- BEGIN Main Container -->  
       <div class="main-container col2-right-layout">
	       <div class="main container"> 
	        <div class="row">                        
                            
<div class="col-sm-12 bounceInUp animated">
<div class="col-main">
<div id="main" class="blog-wrapper">
    
	<div id="primary" class="site-content">
		<div id="content" role="main">
							<article id="post-29" class="blog_entry clearfix" style="text-align:center">
					<header class="blog_entry-header clearfix">
                                          <div class="blog_entry-header-inner">
						<h2 class="blog_entry-title">Trang không tìm thấy</h2>
                                          </div> <!--blog_entry-header-inner-->
					</header> <!--blog_entry-header clearfix-->
					<div class="entry-content">
<div class="entry-content">Trang bạn truy cập đã bị xóa hoặc không tồn tại trên hệ thống.<br><br><a href="/" class="btn btn-primary">Quay lại trang chủ</a>	</div>					
                    </div>
					
				</article>
						
		</div>
	</div>

</div> <!--#main wrapper grid_8-->

</div> <!--col-main-->
</div> <!--col-sm-8-->

        </div>    
	       </div><!--main-container-->
        </div> <!--col2-layout-->