<div id="seomxh-group">
    <div id="cover-seomxh-group">
        <div id="seomxh_box"></div>
        <div id="info-content"> <a href="https://www.facebook.com/groups/bannharieng" target="_blank" rel="nofollow" title="Tham Gia Nhóm muonnha.com.vn Ngay"><i class="fa fa-users"></i> Tham Gia Ngay</a></div>
    </div>
</div>