<div class="content-adv hidden-xs">
<?php 
if($banners) {?>
    <a href="<?=$banners[0]['link']?>"><?=_The_Image($banners[0]['image']);?></a>
<?php    
}

?>
</div>