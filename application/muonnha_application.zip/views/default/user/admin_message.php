<section class="main-content">
<?php $this->load->view('default/require/breadcrumb'); ?>
            <div class="main-wrap-content">
                <div class="pad10">
                <div class="row">
                    <?php $this->load->view('default/user/sidebar'); ?>
                    <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
                        <div class="user_main_title">Thông báo từ ban quản trị</div>
                         <div class="alert alert-success">Chưa có thông báo</div>          
                        </div>
                  
                </div>
                </div>
                
            </div>
        </section>