<html>
<head>
<!-- Basic Styles -->
		<link rel="stylesheet" type="text/css" media="screen" href="<?=base_url()?>public/<?=ADMIN_FOLDER?>/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" media="screen" href="<?=base_url()?>public/<?=ADMIN_FOLDER?>/css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="<?=base_url()?>public/<?=ADMIN_FOLDER?>/fine-uploader/fine-uploader-new.css" />
		<!-- SmartAdmin Styles : Caution! DO NOT change the order -->
		<link rel="stylesheet" type="text/css" media="screen" href="<?=base_url()?>public/<?=ADMIN_FOLDER?>/css/smartadmin-production-plugins.min.css">
		<link rel="stylesheet" type="text/css" media="screen" href="<?=base_url()?>public/<?=ADMIN_FOLDER?>/css/smartadmin-production.min.css">
		<link rel="stylesheet" type="text/css" media="screen" href="<?=base_url()?>public/<?=ADMIN_FOLDER?>/css/smartadmin-skins.min.css">
<script>var base_url = '<?=base_url()?>';</script>
</head>
<body>