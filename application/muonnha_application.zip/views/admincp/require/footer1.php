<?php $this->load->view(ADMIN_FOLDER . '/require/script'); ?>
</body>
</html>