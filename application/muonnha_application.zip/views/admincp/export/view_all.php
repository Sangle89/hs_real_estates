<section id="widget-grid" class="form-add">
	<div class="row">
		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12 sortable-grid ui-sortable">
		<form method="post" action="">
            <button name="export_real_estate" value="1" class="btn btn-primary">Export tin rao <?=$total_real_estate?></button>
        </form>
		</article>
	</div>
</section>